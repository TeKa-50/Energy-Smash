/* core.js (script clásico: sin import/export, se carga primero): utilidades, almacenamiento seguro, carga del catálogo y generador de imágenes */
const $ = (s, c = document) => c.querySelector(s);
const $$ = (s, c = document) => [...c.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"']/g, c => `&#${c.charCodeAt(0)};`); // evita inyección de HTML
const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
const API_BASE = ''; // vacío = mismo servidor (python server/servidor.py). Si el API vive en otro dominio, pon aquí su URL.
const fmt = new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN', maximumFractionDigits: 0 });
const money = n => fmt.format(n); // cambia moneda y localidad aquí

/* LocalStorage (persistente) y SessionStorage (solo la pestaña), con prefijo y a prueba de errores */
const K = 'energysmash:';
const almacen = area => ({
  get: (k, d = null) => { try { const v = area().getItem(K + k); return v === null ? d : JSON.parse(v); } catch { return d; } },
  set: (k, v) => { try { area().setItem(K + k, JSON.stringify(v)); } catch {} },
  del: k => { try { area().removeItem(K + k); } catch {} },
});
const local = almacen(() => localStorage);
const temp = almacen(() => sessionStorage);

/* Catálogo: se llena al leer productos.json */
let DATA = { marcas: [], perfiles: [], productos: [], accesorios: [], guias: [], cupones: [] };
async function loadCatalog() {
  try {
    const r = await fetch('productos.json');
    if (!r.ok) throw new Error(`productos.json respondió ${r.status}`);
    DATA = await r.json();
  } catch (err) {
    // Abierto con doble clic (file://) el navegador bloquea fetch: se usa la copia de js/productos-respaldo.js
    if (!window.PRODUCTOS_RESPALDO) throw err;
    DATA = window.PRODUCTOS_RESPALDO;
    console.info('Catálogo cargado desde js/productos-respaldo.js (sin servidor). Con servidor se lee productos.json.');
  }
}
const prod = id => DATA.productos.find(p => p.id === id);
const acc = id => DATA.accesorios.find(a => a.id === id);
const marca = id => DATA.marcas.find(m => m.id === id)?.nombre ?? id;
const precio = (p, cap) =>
  Math.round(p.precioBase * (1 - (p.oferta?.descuento || 0) / 100)) + (p.capacidades.find(c => c.id === cap)?.extra || 0);

/* Galería por color. Si el color trae "imagenes": ["assets/x.jpg", ...] se usan esas;
   si no, se dibujan tres vistas del teléfono (frontal, trasera, lateral) con el color elegido. */
const imagenes = (p, colorId) => {
  const c = p.colores.find(x => x.id === colorId) || p.colores[0];
  return c.imagenes?.length ? c.imagenes : ['frontal', 'trasera', 'lateral'].map(v => telefonoSVG(c.hex, v));
};
const tono = (h, t) => { const n = parseInt(h.slice(1), 16), f = c => Math.round(t < 0 ? c * (1 + t) : c + (255 - c) * t);
  return '#' + [n >> 16 & 255, n >> 8 & 255, n & 255].map(c => f(c).toString(16).padStart(2, '0')).join(''); };
function telefonoSVG(hex, vista) {
  const a = tono(hex, .3), b = tono(hex, -.4), txt = 'font-family="Impact,Arial Black,sans-serif" font-size="34" font-style="italic" text-anchor="middle"';
  const cuerpo = vista === 'lateral'
    ? '<rect x="222" y="40" width="56" height="480" rx="26" fill="url(#g)"/>'
    : '<rect x="130" y="40" width="240" height="480" rx="40" fill="url(#g)"/>' + (vista === 'frontal'
      ? `<rect x="142" y="52" width="216" height="456" rx="30" fill="#050507"/><clipPath id="c"><rect x="148" y="58" width="204" height="444" rx="25"/></clipPath>
         <g clip-path="url(#c)"><rect x="148" y="58" width="204" height="444" fill="#10101a"/><circle cx="300" cy="140" r="60" fill="#00A8E8" opacity=".25"/>
         <path d="M148 420L352 270V330L148 480Z" fill="#E60012"/><path d="M148 485L352 335V350L148 500Z" fill="#FFB800"/></g>
         <circle cx="250" cy="80" r="7" fill="#000"/><text x="250" y="230" ${txt} fill="#fff">ENERGY</text><text x="250" y="266" ${txt} fill="#FFB800">SMASH</text>`
      : `<rect x="152" y="62" width="100" height="100" rx="26" fill="${b}"/><circle cx="184" cy="94" r="16" fill="#08080b"/><circle cx="222" cy="94" r="16" fill="#08080b"/>
         <circle cx="203" cy="132" r="16" fill="#08080b"/><path d="M265 300l-36 60h24l-12 50 46-68h-26z" fill="#fff" opacity=".25"/>`);
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 560"><defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs>${cuerpo}</svg>`);
}
