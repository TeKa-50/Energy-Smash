#!/usr/bin/env python3
"""Genera el catálogo de Energy Smash: productos.json, js/productos-respaldo.js e imágenes SVG en assets/img/.

Uso:  python tools/generar_catalogo.py
Vuelve a crear todo con una semilla fija (siempre sale el mismo catálogo). Edita aquí marcas, líneas,
precios o colores. Los modelos son ficticios. Para usar fotos reales, cambia las rutas de "imagenes"
en productos.json (y en js/productos-respaldo.js si abres la tienda sin servidor)."""
import json, random, re, shutil
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
IMG = RAIZ / 'assets' / 'img'
rnd = random.Random(2026)

# id: (nombre, tres líneas de modelos, diseño de cámara, factor de precio)
MARCAS = {
    'samsung': ('Samsung', ('Nova', 'Orbit', 'Spark'), 'vertical', 1.10),
    'xiaomi': ('Xiaomi', ('Blaze', 'Lumen', 'Pulse'), 'circulo', .92),
    'motorola': ('Motorola', ('Rally', 'Vector', 'Trail'), 'tres', .95),
    'google': ('Google', ('Lens', 'Aura', 'Echo'), 'barra', 1.12),
    'oneplus': ('OnePlus', ('Volt', 'Dash', 'Flux'), 'circulo', 1.0),
    'honor': ('Honor', ('Zenith', 'Crest', 'Ember'), 'cuadro', 1.05),
    'realme': ('Realme', ('Neon', 'Jolt', 'Wave'), 'diagonal', .90),
    'oppo': ('Oppo', ('Prism', 'Halo', 'Mirage'), 'cuadro', 1.0),
    'vivo': ('Vivo', ('Zephyr', 'Sonic', 'Ridge'), 'circulo', .98),
    'nothing': ('Nothing', ('Glyph', 'Ghost', 'Frost'), 'diagonal', 1.05),
    'huawei': ('Huawei', ('Aurora', 'Titan', 'Sierra'), 'circulo', 1.08),
    'tecno': ('Tecno', ('Lumio', 'Atlas', 'Cobra'), 'tres', .88),
    'infinix': ('Infinix', ('Hyper', 'Orion', 'Kite'), 'vertical', .88),
    'asus': ('Asus', ('Raptor', 'Havoc', 'Viper'), 'cuadro', 1.10),
}
PLAN = [(0, 'Lite'), (0, 'Plus'), (0, 'Pro'), (0, 'Ultra'), (1, 'Lite'), (1, 'Pro'), (2, ''), (2, 'Plus')]  # 8 modelos por marca
T = {  # rangos por gama: precio, RAM, cámara, pantalla, batería, carga, almacenamientos, lentes
    'Lite':  dict(p=(2999, 4999), ram=(4, 6), cam=('13 MP', '50 MP'), pant=('LCD 60 Hz', 'LCD 90 Hz'), bat=(5000, 5500), w=(18, 33), gb=(64, 128), lentes=2, ven=(1200, 3200), rat=(3.9, 4.4)),
    '':      dict(p=(5199, 7499), ram=(6, 8), cam=('50 MP', '64 MP'), pant=('LCD 90 Hz', 'AMOLED 90 Hz'), bat=(5000, 6000), w=(33, 45), gb=(128, 256), lentes=2, ven=(900, 2600), rat=(4.0, 4.5)),
    'Plus':  dict(p=(8499, 12999), ram=(8, 12), cam=('64 MP', '108 MP'), pant=('AMOLED 120 Hz',), bat=(5000, 6000), w=(45, 67), gb=(128, 256, 512), lentes=3, ven=(500, 1800), rat=(4.2, 4.7)),
    'Pro':   dict(p=(14499, 20999), ram=(12, 16), cam=('108 MP', '200 MP'), pant=('AMOLED 120 Hz', 'AMOLED 144 Hz'), bat=(5200, 6500), w=(67, 100), gb=(256, 512), lentes=3, ven=(250, 1100), rat=(4.4, 4.8)),
    'Ultra': dict(p=(24999, 34999), ram=(12, 16), cam=('200 MP', '200 MP + zoom 5x'), pant=('AMOLED 144 Hz LTPO',), bat=(5500, 6500), w=(80, 120), gb=(256, 512, 1024), lentes=4, ven=(100, 700), rat=(4.5, 4.9)),
}
COLORES = [('negro', 'Negro medianoche', '#26262b'), ('blanco', 'Blanco perla', '#e9edf2'), ('azul', 'Azul glaciar', '#4f7fb5'),
           ('verde', 'Verde salvia', '#6f8f72'), ('rojo', 'Rojo magma', '#e0302a'), ('lila', 'Lila', '#8a73c4'),
           ('dorado', 'Dorado', '#c9a24b'), ('gris', 'Gris tormenta', '#4a5058'), ('menta', 'Menta', '#7fc4a8'),
           ('rosa', 'Rosa cuarzo', '#d98fa6'), ('naranja', 'Naranja solar', '#e8803a'), ('turquesa', 'Turquesa', '#2aa6a6')]

# ---------- imágenes SVG ----------
def tono(h, t):
    n = int(h[1:], 16)
    f = lambda c: round(c * (1 + t) if t < 0 else c + (255 - c) * t)
    return '#' + ''.join(f'{f(c):02x}' for c in (n >> 16 & 255, n >> 8 & 255, n & 255))

OFFS = {2: [(-18, 0), (18, 0)], 3: [(0, -20), (-20, 14), (20, 14)], 4: [(-20, -20), (20, -20), (-20, 20), (20, 20)]}

def lente(x, y, r=15):
    return (f'<circle cx="{x}" cy="{y}" r="{r}" fill="#08080b" stroke="#5a5a64" stroke-width="3"/>'
            f'<circle cx="{x}" cy="{y}" r="{r // 3}" fill="#00A8E8" opacity=".55"/>')

def camara(diseno, n):
    if diseno == 'vertical':
        return (f'<rect x="152" y="62" width="58" height="{n * 40 + 14}" rx="29" fill="#00000066"/>'
                + ''.join(lente(181, 90 + i * 40) for i in range(n)))
    if diseno == 'circulo':
        return '<circle cx="250" cy="128" r="58" fill="#00000066"/>' + ''.join(lente(250 + dx, 128 + dy, 14) for dx, dy in OFFS[min(n, 4) if n > 1 else 2])
    if diseno == 'barra':
        xs = [170 + i * (160 // max(n - 1, 1)) for i in range(n)]
        return '<rect x="130" y="108" width="240" height="64" fill="#00000066"/>' + ''.join(lente(x, 140, 17) for x in xs)
    if diseno == 'diagonal':
        pos = [(180, 100, 24), (222, 144, 20), (178, 152, 12), (228, 98, 10)][:n]
        return ''.join(lente(x, y, r) for x, y, r in pos)
    # 'cuadro' y 'tres': módulo cuadrado
    return '<rect x="152" y="62" width="104" height="104" rx="26" fill="#00000066"/>' + ''.join(lente(204 + dx, 114 + dy, 13) for dx, dy in OFFS[min(n, 4) if n > 1 else 2])

def svg(vista, hex_, marca, nombre, diseno, lentes, muesca):
    a, b = tono(hex_, .3), tono(hex_, -.4)
    tx = 'font-family="Arial Black,Impact,sans-serif" text-anchor="middle"'
    if vista == 'lateral':
        cuerpo = '<rect x="222" y="40" width="56" height="480" rx="26" fill="url(#g)"/><rect x="276" y="140" width="5" height="54" rx="2" fill="#0006"/><rect x="276" y="210" width="5" height="84" rx="2" fill="#0006"/>'
    elif vista == 'trasera':
        cuerpo = (f'<rect x="130" y="40" width="240" height="480" rx="40" fill="url(#g)"/>{camara(diseno, lentes)}'
                  f'<text x="250" y="470" {tx} font-size="20" fill="#fff" opacity=".45">{marca.upper()}</text>')
    else:
        punto = '<rect x="228" y="60" width="44" height="14" rx="7" fill="#000"/>' if muesca else '<circle cx="250" cy="80" r="7" fill="#000"/>'
        fs = 30 if len(nombre) <= 10 else 22
        cuerpo = (f'<rect x="130" y="40" width="240" height="480" rx="40" fill="url(#g)"/><rect x="141" y="51" width="218" height="458" rx="31" fill="#050507"/>'
                  f'<clipPath id="c"><rect x="147" y="57" width="206" height="446" rx="26"/></clipPath>'
                  f'<g clip-path="url(#c)"><rect x="147" y="57" width="206" height="446" fill="url(#w)"/><circle cx="310" cy="150" r="70" fill="{a}" opacity=".35"/>'
                  f'<path d="M147 400L353 250V310L147 460Z" fill="{a}" opacity=".9"/><path d="M147 468L353 318V332L147 482Z" fill="#FFB800"/></g>{punto}'
                  f'<text x="250" y="150" {tx} font-size="42" fill="#fff" opacity=".9">9:41</text>'
                  f'<text x="250" y="226" {tx} font-size="14" fill="#fff" opacity=".7">{marca.upper()}</text>'
                  f'<text x="250" y="256" {tx} font-size="{fs}" font-style="italic" fill="#fff">{nombre.upper()}</text>')
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 560" role="img" aria-label="{marca} {nombre}"><defs>'
            f'<linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{a}"/><stop offset="1" stop-color="{b}"/></linearGradient>'
            f'<linearGradient id="w" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{tono(hex_, -.55)}"/><stop offset="1" stop-color="#0a0a12"/></linearGradient></defs>'
            f'<ellipse cx="250" cy="540" rx="150" ry="12" fill="#000" opacity=".35"/>{cuerpo}</svg>')

# ---------- productos ----------
if IMG.exists(): shutil.rmtree(IMG)
IMG.mkdir(parents=True)
P = []
for mid, (mn, lineas, diseno, factor) in MARCAS.items():
    for li, var in PLAN:
        t = T[var]; linea = lineas[li]
        nombre = f'{linea} {var}'.strip(); pid = f'{mid}-{linea.lower()}' + (f'-{var.lower()}' if var else '')
        precio = int(round(rnd.uniform(*t['p']) * factor, -2)) - 1
        ram, cam, pant = rnd.choice(t['ram']), rnd.choice(t['cam']), rnd.choice(t['pant'])
        bat, w = rnd.choice(range(t['bat'][0], t['bat'][1] + 1, 500)), rnd.choice(t['w'])
        if mid == 'asus':  # marca gamer: más RAM y pantalla rápida
            ram = max(ram, 8); pant = 'AMOLED 144 Hz' if var in ('Pro', 'Ultra') else 'AMOLED 120 Hz'
        hz = int(re.search(r'(\d+) Hz', pant).group(1))
        perf = []
        if mid == 'asus' or (ram >= 12 and hz >= 120): perf.append('gamer')
        if cam.startswith(('108', '200')) or (mid == 'google' and var in ('Plus', 'Pro', 'Ultra')): perf.append('fotografia')
        if bat >= 6000: perf.append('bateria')
        if var in ('Lite', ''): perf.append('economico')
        if var in ('Pro', 'Ultra') or (var == 'Plus' and ram >= 12): perf.append('trabajo')
        perf = perf or ['trabajo']
        step = int(round(precio * .11, -2))
        caps = [{'id': '1 TB' if g == 1024 else f'{g} GB', 'extra': e} for g, e in zip(t['gb'], [0, step, int(round(step * 2.2, -2))])]
        cols = []
        for cid, cn, hx in rnd.sample(COLORES, 2 if var in ('Lite', '') else 3):
            rutas = []
            for v in ('frontal', 'trasera', 'lateral'):
                ruta = f'assets/img/{pid}-{cid}-{v}.svg'
                (RAIZ / ruta).write_text(svg(v, hx, mn, nombre, diseno, t['lentes'], var in ('Lite', '')), encoding='utf-8')
                rutas.append(ruta)
            cols.append({'id': cid, 'nombre': cn, 'hex': hx, 'imagenes': rutas})
        specs = [pant, f'{ram} GB RAM', cam] + (['5G'] if var or rnd.random() < .5 else [])
        P.append({'id': pid, 'marca': mid, 'nombre': nombre, 'descripcion': f'{pant}, cámara de {cam}, batería de {bat} mAh y carga de {w} W.',
                  'precioBase': precio, 'rating': round(rnd.uniform(*t['rat']), 1), 'ventas': rnd.randint(*t['ven']),
                  'perfiles': perf, 'specs': specs, 'capacidades': caps, 'colores': cols})
for p in rnd.sample([p for p in P if not p['id'].endswith('ultra')], 8):  # ofertas flash
    p['oferta'] = {'descuento': rnd.choice([10, 15, 20, 25, 30]), 'vendido': rnd.randint(25, 92)}
next(p for p in P if p['id'] == 'samsung-nova-ultra')['nuevo'] = True   # protagonista del banner
rnd.shuffle(P)

DATA = {
    'marcas': [{'id': k, 'nombre': v[0]} for k, v in MARCAS.items()],
    'perfiles': [{'id': 'gamer', 'nombre': 'Gamer'}, {'id': 'fotografia', 'nombre': 'Fotografía'}, {'id': 'bateria', 'nombre': 'Batería de dos días'},
                 {'id': 'trabajo', 'nombre': 'Trabajo y estudio'}, {'id': 'economico', 'nombre': 'Mejor precio'}],
    'productos': P,
    'accesorios': [{'id': 'cargador-65', 'nombre': 'Cargador GaN 65 W', 'categoria': 'Carga', 'precio': 699, 'icono': '🔌'},
                   {'id': 'audifonos', 'nombre': 'Audífonos inalámbricos', 'categoria': 'Audio', 'precio': 1299, 'icono': '🎧'},
                   {'id': 'funda', 'nombre': 'Funda blindada', 'categoria': 'Protección', 'precio': 349, 'icono': '🛡️'},
                   {'id': 'powerbank', 'nombre': 'Power bank 20 000 mAh', 'categoria': 'Carga', 'precio': 899, 'icono': '🔋'},
                   {'id': 'vidrio', 'nombre': 'Vidrio templado (2 piezas)', 'categoria': 'Protección', 'precio': 199, 'icono': '🪟'},
                   {'id': 'cable', 'nombre': 'Cable USB-C trenzado 2 m', 'categoria': 'Carga', 'precio': 249, 'icono': '🔗'},
                   {'id': 'soporte', 'nombre': 'Soporte gamer con ventilador', 'categoria': 'Gaming', 'precio': 549, 'icono': '🎮'},
                   {'id': 'microsd', 'nombre': 'Tarjeta microSD 256 GB', 'categoria': 'Almacenamiento', 'precio': 429, 'icono': '💾'}],
    'guias': [{'id': 'g1', 'titulo': 'Cómo elegir tu smartphone según cómo lo usas', 'tiempo': '6 min', 'icono': '🧭', 'acento': 'red'},
              {'id': 'g2', 'titulo': 'Hz, nits y mAh: qué significan en la práctica', 'tiempo': '5 min', 'icono': '📊', 'acento': 'gold'},
              {'id': 'g3', 'titulo': '10 ajustes para que tu batería dure más', 'tiempo': '4 min', 'icono': '⚡', 'acento': 'cyan'}],
    'cupones': [{'codigo': 'SMASH10', 'tipo': 'porcentaje', 'valor': 10, 'descripcion': '10% de descuento en tu carrito'},
                {'codigo': 'ENERGY500', 'tipo': 'fijo', 'valor': 500, 'minimo': 5000, 'descripcion': '$500 menos en compras desde $5,000'}],
}
linea_json = lambda o: json.dumps(o, ensure_ascii=False, separators=(',', ':'))
txt = '{\n' + ',\n'.join(f'"{k}":[\n' + ',\n'.join(linea_json(x) for x in v) + '\n]' for k, v in DATA.items()) + '\n}\n'
(RAIZ / 'productos.json').write_text(txt, encoding='utf-8')
(RAIZ / 'js' / 'productos-respaldo.js').write_text(
    '/* Copia de productos.json para abrir la tienda sin servidor. Se regenera con tools/generar_catalogo.py. */\nwindow.PRODUCTOS_RESPALDO = ' + txt.rstrip() + ';\n', encoding='utf-8')
print(f'{len(P)} modelos, {len(MARCAS)} marcas, {sum(len(p["colores"]) for p in P)} colores, {len(list(IMG.glob("*.svg")))} imágenes')
