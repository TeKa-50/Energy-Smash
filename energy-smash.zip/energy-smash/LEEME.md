# Energy Smash

Tienda de smartphones (HTML + CSS + JavaScript) con boletín por correo.

## Cómo abrirla
1. Descomprime **todo** el zip y no muevas archivos: `index.html` necesita las carpetas `css/`, `js/` y `assets/` a su lado.
2. **Con servidor (recomendado, activa el boletín):** instala Python 3.8+ y ejecuta
   `python server/servidor.py`, luego abre http://localhost:8000
3. **Sin servidor:** doble clic en `index.html`. Todo funciona excepto el envío de correos del boletín.

## Boletín de ofertas por correo
- Copia `server/.env.ejemplo` como `server/.env` y completa los datos SMTP de tu proveedor (Gmail, Outlook, Mailgun, etc.).
- Sin SMTP, los correos se guardan como archivos `.eml` en `server/datos/bandeja/` (modo simulación, ábrelos con tu cliente de correo).
- Flujo: el visitante se suscribe, recibe un correo de confirmación, y solo los confirmados reciben ofertas. Cada correo trae un enlace de baja.
- Enviar el boletín: `python server/servidor.py ofertas` (usa los productos con `"oferta"` de `productos.json`).
  También por API: define `ADMIN_TOKEN` y haz `POST /api/admin/enviar-ofertas` con la cabecera `Authorization: Bearer <token>`.
- Ver suscriptores: `python server/servidor.py suscriptores`.

## Catálogo
- `productos.json` tiene 112 modelos (ficticios), con sus imágenes en `assets/img/`.
- Para cambiar el catálogo: edita `tools/generar_catalogo.py` y ejecútalo (regenera `productos.json`, `js/productos-respaldo.js` y las imágenes), o edita el JSON a mano.
- Para usar fotos reales: cambia las rutas de `"imagenes"` de cada color (en `productos.json` y, si abres sin servidor, en `js/productos-respaldo.js`).

## Páginas legales
`terminos.html`, `privacidad.html` y `devoluciones.html` son plantillas. Completa los datos resaltados en amarillo (razón social, domicilio, correos, plazos) y haz que las revise un abogado antes de publicar.
